select * from my_elective.electives;
select * from my_elective.users;
select * from my_elective.histories;
select * from my_elective.ratings;
