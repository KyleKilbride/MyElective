use my_elective;

INSERT INTO `users` (`user_name`, `password`, `first_name`, `last_name`, `program`, `email_address`, `status`) VALUES ('superman346', 'lastSUN', 'Kal', 'El', 'Farming', 'el1933@algonquinlive.com', 'user');
INSERT INTO `users` (`user_name`, `password`, `first_name`, `last_name`, `program`, `email_address`, `status`) VALUES ('i''mbatman', 'aintnorest123', 'Bruce', 'Wayne', 'Forensics', 'wayn1939@algonquinlive.com', 'user');
INSERT INTO `users` (`user_name`, `password`, `first_name`, `last_name`, `program`, `email_address`, `status`) VALUES ('DAflash', 'arribaARRIBA', 'Barry', 'Allen', 'Kinesiology', 'alle1956@algonquinlive.com', 'user');
INSERT INTO `users` (`user_name`, `password`, `first_name`, `last_name`, `program`, `email_address`, `status`) VALUES ('green-lantern', 'yElLoWbAd', 'Hal', 'Jordan', 'Aviation', 'jord1959@algonquinlive.com', 'user');
INSERT INTO `users` (`user_name`, `password`, `first_name`, `last_name`, `program`, `email_address`, `status`) VALUES ('wonder_woman', 'themyscira4eva', 'Diana', 'Prince', 'Classical Studies', 'boyd0077@algonquinlive.com', 'user');
