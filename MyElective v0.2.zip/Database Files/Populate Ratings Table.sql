use my_elective;

INSERT INTO `ratings` (`rating`, `hours_per_week`, `comment`, `users_id`, `electives_id`) VALUES ('6', '5', 'Lorem Ipsem', '4', '1');
INSERT INTO `ratings` (`rating`, `hours_per_week`, `comment`, `users_id`, `electives_id`) VALUES ('2', '7', 'Lorem Ipsem', '4', '23');
INSERT INTO `ratings` (`rating`, `hours_per_week`, `comment`, `users_id`, `electives_id`) VALUES ('8', '1', 'Lorem Ipsem', '4', '15');
INSERT INTO `ratings` (`rating`, `hours_per_week`, `comment`, `users_id`, `electives_id`) VALUES ('2', '1', 'i''m batman', '5', '2');
INSERT INTO `ratings` (`rating`, `hours_per_week`, `comment`, `users_id`, `electives_id`) VALUES ('5', '2', 'i''m batman', '5', '23');
INSERT INTO `ratings` (`rating`, `hours_per_week`, `comment`, `users_id`, `electives_id`) VALUES ('6', '1', 'i''m batman', '5', '30');
INSERT INTO `ratings` (`rating`, `hours_per_week`, `comment`, `users_id`, `electives_id`) VALUES ('4', '3', 'Lorem Ipsem', '6', '1');
INSERT INTO `ratings` (`rating`, `hours_per_week`, `comment`, `users_id`, `electives_id`) VALUES ('6', '7', 'Lorem Ipsem', '6', '22');
INSERT INTO `ratings` (`rating`, `hours_per_week`, `comment`, `users_id`, `electives_id`) VALUES ('10', '5', 'Lorem Ipsem', '6', '32');
INSERT INTO `ratings` (`rating`, `hours_per_week`, `comment`, `users_id`, `electives_id`) VALUES ('9', '13', 'Lorem Ipsem', '7', '1');
INSERT INTO `ratings` (`rating`, `hours_per_week`, `comment`, `users_id`, `electives_id`) VALUES ('1', '25', 'Lorem Ipsem', '7', '23');
INSERT INTO `ratings` (`rating`, `hours_per_week`, `comment`, `users_id`, `electives_id`) VALUES ('3', '2', 'Lorem Ipsem', '7', '1');
INSERT INTO `ratings` (`rating`, `hours_per_week`, `comment`, `users_id`, `electives_id`) VALUES ('7', '3', 'Lorem Ipsem', '8', '5');
INSERT INTO `ratings` (`rating`, `hours_per_week`, `comment`, `users_id`, `electives_id`) VALUES ('6', '4', 'Lorem Ipsem', '8', '12');
INSERT INTO `ratings` (`rating`, `hours_per_week`, `comment`, `users_id`, `electives_id`) VALUES ('6', '6', 'Lorem Ipsem', '8', '11');